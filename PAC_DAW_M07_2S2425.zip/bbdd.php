<?php 
    define("DATABASE","pac2s2425"); 
    define("HOST", "");
    define("USER", "");
    define("PASSWORD", "");
?>

