<?php

include_once "bbdd.php";

function crearConexion() {
    $conexion = HUECO1(HOST, USER, PASSWORD, DATABASE);
    if (!$conexion) {
        die("Error de conexión: " . mysqli_connect_error());
    }
    return $conexion;
}

function getPosts() {
    $db = HUECO2();
    $sql = "SELECT * FROM posts";
    $result = HUECO3($db, $sql);
    mysqli_close($db);
    if (HUECO4($result) > 0) {
        return $result;
    } else {
        return "No hay posts";
    }
}

function addPost($user, $title, $body) {
    $db = HUECO5();
    $sql = "INSERT INTO posts (user, title, body) VALUES ('$user','$title','$body' )";
    $result = HUECO6($db, $sql);
    mysqli_close($db);
    if ($result) {
        return $result;
    } else {
        echo "Error al crear post.";
    } 
}
